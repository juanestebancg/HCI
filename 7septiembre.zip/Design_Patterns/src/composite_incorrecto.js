
/*function shoppingCar(typePaella){ 
    this.typePaella = typePaella;
    var arrayElements = [];
    this.compositeProto =function() {
        var objectComposite = {
             add: function(product){
                arrayElements.push(product);
                return arrayElements;
            },

            remove: function (product){
                arrayElements.split(0,arrayElements.length);
                arrayElements.add(product);

                return arrayElements;
        }

     }
           
     return objectComposite;
   }
    
    

}
*/


shoppingCar.prototype = {
    add:function(products){
        this.arrayElements.push(products);
        //return arrayElements
    },
    remove: function(products){
        this.arrayElements.splice(0,this.arrayElements.length)
        this.arrayElements.push(products);
        // return arrayElements
    }

}


function buildShoppingCar(arr){//tipo de producto, producto){
    var car = new shoppingCar("paella"); 
    var resultCar;
    for(var i = 0; i < arr.length;i++){
       car.add(arr[i]);

    }
    //var resultCar = car.compositeProto().add(product);

    return car;

}

